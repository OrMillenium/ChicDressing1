<?php if ( !\defined('ABSPATH') ) { return false; }
return [
    'timestamp' => 1641231644,
    'size' => 45497,
    'filesize' => 66474,
    'files' => 44,
];
/*@DOCKET_CACHE_EOF*/