=== Ashe Extra ===
Contributors: WP Royal
Stable tag: 1.2.6
Tested up to: 5.5.3
Requires at least: 4.6
License: GPLv2 or later

Adds One Click Demo Import functionality for Ashe theme.

== Description ==

Adds One Click Demo Import functionality for Ashe theme. When activated you will be able to import Demo Content for the Ashe theme.